# ClickLearn company logos

Company logos for the Claude **company-lookup** cards. A GitHub Action copies
each company's logo from HubSpot (`hs_logo_url`) into `logos/` every night, and
the cards load them through jsDelivr (one of the few image sources the cards
are allowed to use).

Files are named by a short hash of the company domain, not the domain itself,
so the repo doesn't list ClickLearn's companies in clear text.

## Setup (about 15 minutes)

### 1. HubSpot: create a service key (HubSpot super admin)
1. In HubSpot, go to **Settings → Integrations → Service Keys → Create a service key**
   (in some accounts it's under **Development → Keys → Service Keys**).
2. Name: `Logo sync for Claude`.
3. Scopes: tick only **crm.objects.companies.read**.
4. Create the key and copy it.

A private app token works too, if you already have one with the same scope.

### 2. GitHub: create the repo
1. Create a **public** repository, e.g. `DennisHauge/clicklearn-logos`.
   (It must be public for jsDelivr to serve the files.)
2. Upload everything in this folder, keeping the folder structure:
   - `.github/workflows/sync-logos.yml`
   - `scripts/sync_logos.py`
   - `logos/` (an empty `.gitkeep` file is enough)
   - `README.md`

### 3. GitHub: add the token as a secret
1. In the repo, go to **Settings → Secrets and variables → Actions → New repository secret**.
2. Name: `HUBSPOT_TOKEN`
3. Value: the token from step 1.

### 4. Run it once
1. Go to the **Actions** tab, choose **Sync company logos from HubSpot**, and click **Run workflow**.
2. When it's done (a few minutes, longer the first time), the `logos/` folder is filled.
3. After that it runs by itself every night.

## How the card finds a logo
1. Take the company domain, lowercase, without `https://`, `www.` or a path
   (e.g. `allient.com`).
2. Compute `sha256(domain)` and take the first 20 hex characters.
3. Load `https://cdn.jsdelivr.net/gh/DennisHauge/clicklearn-logos@main/logos/<hash>.png`.
4. If that fails, show the company's initials.

The card does steps 2–4 itself in the browser:

```html
<div class="cl-logo" data-domain="allient.com"><span>AL</span></div>
<script>
(async () => {
  try {
    const el = document.querySelector('.cl-logo');
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(el.dataset.domain));
    const hash = [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 20);
    const img = new Image();
    img.onload = () => { img.style.cssText = 'max-width:44px;max-height:44px'; el.replaceChildren(img); };
    img.src = 'https://cdn.jsdelivr.net/gh/DennisHauge/clicklearn-logos@main/logos/' + hash + '.png';
  } catch (e) { /* keep the initials */ }
})();
</script>
```

## Good to know
- **What is public:** the logo images themselves (and the HubSpot logo URLs in
  `logos/manifest.json`). Company names and domains are not stored in the repo,
  but someone browsing it could still recognise companies from their logos.
- **New or changed logos** show up the morning after they appear in HubSpot.
  jsDelivr can cache old files for up to about 12 hours; the workflow asks it to
  refresh changed files.
- **Rotating the token:** rotate the service key in HubSpot (Rotate button) and update the
  `HUBSPOT_TOKEN` secret. Nothing else changes.
- **To stop it:** disable the workflow in the Actions tab, or delete the service key
  in HubSpot.
